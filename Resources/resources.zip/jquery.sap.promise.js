/*!
 * UI development toolkit for HTML5 (OpenUI5)
 * (c) Copyright 2009-2016 SAP SE or an SAP affiliate company.
 * Licensed under the Apache License, Version 2.0 - see LICENSE.txt.
 */
if(sap.ui.Device.browser.edge){window.Promise=undefined;}if(!window.Promise){jQuery.sap.require("sap.ui.thirdparty.es6-promise");ES6Promise.polyfill();}
